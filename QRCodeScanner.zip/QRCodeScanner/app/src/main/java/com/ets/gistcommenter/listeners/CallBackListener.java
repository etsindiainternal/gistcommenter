package com.ets.gistcommenter.listeners;

public interface CallBackListener {

    public void getdata(String data);
}
